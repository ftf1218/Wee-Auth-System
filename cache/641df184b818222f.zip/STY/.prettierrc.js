module.exports = {
    tabWidth: 2,
}